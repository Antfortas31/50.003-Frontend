import * as algo from './algorithm';

export function fuzzer(){
    var maxLength = 250;
    var length = 0;
    var fuzzBoothlist = [];
    var fourplus = 0;
    for(var i=0;i<10000;i++){
        var randLength = (Math.ceil(Math.random()*10))/2
        var randWidth = (Math.ceil(Math.random()*10))/2
        //var randTypeInt = Math.ceil(Math.random()*2)
        var Booth = new algo.Booth(i,i,i,randLength,randWidth);
        //console.log(randLength);
        fuzzBoothlist.push(Booth);
        length+=Booth.length;
        if (randLength>4){
            fourplus++;
        }
        if (length>maxLength){
            break;
        }
    }
    //console.log("Number of Fuzzer Booths: " + fuzzBoothlist.length);
    console.log("Width>4 " + fourplus);
    return [fuzzBoothlist,length,fuzzBoothlist.length];
}